package com.jalsanchay.tracker.ui.report

import android.app.Application
import android.graphics.Color
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.AndroidViewModel
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.jalsanchay.tracker.data.database.AppDatabase
import com.jalsanchay.tracker.data.repository.RainfallRepository
import com.jalsanchay.tracker.databinding.FragmentReportBinding
import java.text.SimpleDateFormat
import java.util.*

class ReportViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = RainfallRepository(AppDatabase.getDatabase(app).rainfallDao())
    val monthlyEntries = repo.getMonthlyEntries()
    val monthlyTotal = repo.getMonthlyLiters()
    val allTimeTotal = repo.totalLiters
}

class ReportFragment : Fragment() {

    private var _binding: FragmentReportBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ReportViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentReportBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val sdf = SimpleDateFormat("dd MMM", Locale.getDefault())

        viewModel.monthlyTotal.observe(viewLifecycleOwner) {
            binding.tvMonthTotal.text = "This Month: %.0f L".format(it ?: 0.0)
        }
        viewModel.allTimeTotal.observe(viewLifecycleOwner) {
            binding.tvAllTimeTotal.text = "All Time: %.0f L".format(it ?: 0.0)
        }
        viewModel.monthlyEntries.observe(viewLifecycleOwner) { entries ->
            if (entries.isEmpty()) {
                binding.barChart.visibility = View.GONE
                binding.tvNoData.visibility = View.VISIBLE
                return@observe
            }
            binding.barChart.visibility = View.VISIBLE
            binding.tvNoData.visibility = View.GONE
            val barEntries = entries.mapIndexed { i, e -> BarEntry(i.toFloat(), e.litersCollected.toFloat()) }
            val labels = entries.map { sdf.format(Date(it.date)) }
            val dataSet = BarDataSet(barEntries, "Liters Collected").apply {
                color = Color.parseColor("#1565C0"); valueTextSize = 10f
            }
            binding.barChart.apply {
                data = BarData(dataSet)
                xAxis.apply {
                    valueFormatter = IndexAxisValueFormatter(labels)
                    position = XAxis.XAxisPosition.BOTTOM
                    granularity = 1f; labelRotationAngle = -45f
                }
                axisRight.isEnabled = false; description.isEnabled = false
                animateY(800); invalidate()
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
