package com.jalsanchay.tracker.data.repository

import androidx.lifecycle.LiveData
import com.jalsanchay.tracker.data.dao.RainfallDao
import com.jalsanchay.tracker.data.entity.RainfallEntry
import java.util.Calendar

class RainfallRepository(private val dao: RainfallDao) {

    val allEntries: LiveData<List<RainfallEntry>> = dao.getAllEntries()
    val totalLiters: LiveData<Double?> = dao.getTotalLiters()

    fun getTodayEntry(): LiveData<RainfallEntry?> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis
        cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59); cal.set(Calendar.SECOND, 59)
        val end = cal.timeInMillis
        return dao.getTodayEntry(start, end)
    }

    fun getMonthlyLiters(): LiveData<Double?> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        return dao.getMonthlyLiters(cal.timeInMillis)
    }

    fun getMonthlyEntries(): LiveData<List<RainfallEntry>> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        return dao.getMonthlyEntries(cal.timeInMillis)
    }

    suspend fun insert(entry: RainfallEntry) = dao.insert(entry)
    suspend fun delete(entry: RainfallEntry) = dao.delete(entry)
}
