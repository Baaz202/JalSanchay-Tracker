package com.jalsanchay.tracker.ui.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.map
import com.jalsanchay.tracker.data.database.AppDatabase
import com.jalsanchay.tracker.data.repository.RainfallRepository

class DashboardViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = RainfallRepository(AppDatabase.getDatabase(app).rainfallDao())
    val totalLiters: LiveData<Double> = repo.totalLiters.map { it ?: 0.0 }
    val monthlyLiters: LiveData<Double> = repo.getMonthlyLiters().map { it ?: 0.0 }
    val todayEntry = repo.getTodayEntry()
}
