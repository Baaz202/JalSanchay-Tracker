package com.jalsanchay.tracker.ui.setup

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.preference.PreferenceManager
import com.jalsanchay.tracker.R
import com.jalsanchay.tracker.databinding.FragmentSetupBinding
import com.jalsanchay.tracker.utils.WaterCalculator

class SetupFragment : Fragment() {

    private var _binding: FragmentSetupBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSetupBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val prefs = PreferenceManager.getDefaultSharedPreferences(requireContext())

        val savedArea = prefs.getFloat("roof_area", 0f)
        val savedCap = prefs.getFloat("tank_capacity", 0f)
        val savedCoeff = prefs.getFloat("runoff_coeff", 0.85f)

        if (savedArea > 0) binding.etRoofArea.setText(savedArea.toString())
        if (savedCap > 0) binding.etTankCapacity.setText(savedCap.toString())
        binding.etRunoffCoeff.setText(savedCoeff.toString())

        binding.btnSaveSetup.setOnClickListener {
            val area = WaterCalculator.parseDouble(binding.etRoofArea.text.toString())
            val tank = WaterCalculator.parseDouble(binding.etTankCapacity.text.toString())
            val coeff = WaterCalculator.parseDouble(binding.etRunoffCoeff.text.toString())

            if (area == null || area <= 0) { binding.etRoofArea.error = "Enter valid roof area"; return@setOnClickListener }
            if (tank == null || tank <= 0) { binding.etTankCapacity.error = "Enter valid tank capacity"; return@setOnClickListener }
            if (coeff == null || coeff !in 0.1..1.0) { binding.etRunoffCoeff.error = "Enter value between 0.1 and 1.0"; return@setOnClickListener }

            prefs.edit()
                .putFloat("roof_area", area.toFloat())
                .putFloat("tank_capacity", tank.toFloat())
                .putFloat("runoff_coeff", coeff.toFloat())
                .putBoolean("setup_complete", true)
                .apply()

            Toast.makeText(requireContext(), "Setup Saved! \uD83D\uDCA7", Toast.LENGTH_SHORT).show()
            findNavController().navigate(R.id.action_setup_to_dashboard)
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
