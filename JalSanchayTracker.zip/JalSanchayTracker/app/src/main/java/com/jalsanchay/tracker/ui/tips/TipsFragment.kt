package com.jalsanchay.tracker.ui.tips

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.jalsanchay.tracker.databinding.FragmentTipsBinding
import com.jalsanchay.tracker.databinding.ItemTipBinding

data class Tip(val emoji: String, val title: String, val description: String)

class TipAdapter(private val tips: List<Tip>) : RecyclerView.Adapter<TipAdapter.TipVH>() {
    inner class TipVH(val binding: ItemTipBinding) : RecyclerView.ViewHolder(binding.root)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        TipVH(ItemTipBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: TipVH, position: Int) {
        holder.binding.tvEmoji.text = tips[position].emoji
        holder.binding.tvTipTitle.text = tips[position].title
        holder.binding.tvTipDesc.text = tips[position].description
    }
    override fun getItemCount() = tips.size
}

class TipsFragment : Fragment() {

    private var _binding: FragmentTipsBinding? = null
    private val binding get() = _binding!!

    private val tips = listOf(
        Tip("\uD83C\uDFE0", "Clean Your Roof", "Sweep roof regularly to improve runoff efficiency by 15%."),
        Tip("\uD83D\uDD27", "First-Flush Diverter", "Divert first 1-2mm of rain to remove pollutants from roof."),
        Tip("\uD83D\uDD75\uFE0F", "Check for Leaks", "Inspect pipes and tank monthly to avoid water loss."),
        Tip("\uD83C\uDF3F", "Use Mesh Filters", "Leaf guards on gutters prevent blockages."),
        Tip("\uD83D\uDCA7", "Know Your Coefficient", "Metal roofs achieve 0.9+; concrete may be 0.75."),
        Tip("\uD83C\uDF31", "Use for Gardening", "200L rainwater irrigates 20 sq ft garden for 3 days.")
    )

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTipsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rvTips.layoutManager = LinearLayoutManager(requireContext())
        binding.rvTips.adapter = TipAdapter(tips)
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
