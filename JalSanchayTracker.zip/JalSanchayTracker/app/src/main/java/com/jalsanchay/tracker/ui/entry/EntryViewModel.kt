package com.jalsanchay.tracker.ui.entry

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jalsanchay.tracker.data.database.AppDatabase
import com.jalsanchay.tracker.data.entity.RainfallEntry
import com.jalsanchay.tracker.data.repository.RainfallRepository
import kotlinx.coroutines.launch

class EntryViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = RainfallRepository(AppDatabase.getDatabase(app).rainfallDao())

    fun saveEntry(entry: RainfallEntry, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repo.insert(entry)
            onSuccess()
        }
    }
}
