package com.jalsanchay.tracker.utils

object WaterCalculator {

    fun calculateLiters(
        roofAreaSqFt: Double,
        rainfallMm: Double,
        runoffCoefficient: Double = 0.85
    ): Double {
        if (roofAreaSqFt <= 0 || rainfallMm <= 0) return 0.0
        return roofAreaSqFt * rainfallMm * runoffCoefficient
    }

    fun toHouseholdDays(liters: Double, membersCount: Int = 4): Double {
        return liters / (membersCount * 135.0)
    }

    fun tankFillPercent(litersCollected: Double, tankCapacityLiters: Double): Int {
        if (tankCapacityLiters <= 0) return 0
        return ((litersCollected / tankCapacityLiters) * 100).coerceIn(0.0, 100.0).toInt()
    }

    fun parseDouble(input: String): Double? {
        return input.trim().toDoubleOrNull()?.takeIf { it >= 0 }
    }

    fun co2SavedKg(liters: Double): Double = (liters / 1000.0) * 0.35
}
