package com.jalsanchay.tracker.ui.entry

import android.os.Bundle
import android.text.*
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.preference.PreferenceManager
import com.jalsanchay.tracker.data.entity.RainfallEntry
import com.jalsanchay.tracker.databinding.FragmentEntryBinding
import com.jalsanchay.tracker.utils.WaterCalculator
import java.text.SimpleDateFormat
import java.util.*

class EntryFragment : Fragment() {

    private var _binding: FragmentEntryBinding? = null
    private val binding get() = _binding!!
    private val viewModel: EntryViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentEntryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val prefs = PreferenceManager.getDefaultSharedPreferences(requireContext())
        val roofArea = prefs.getFloat("roof_area", 0f).toDouble()
        val coeff = prefs.getFloat("runoff_coeff", 0.85f).toDouble()

        binding.tvDate.text = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())

        binding.etRainfallMm.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val mm = WaterCalculator.parseDouble(s.toString()) ?: 0.0
                val liters = WaterCalculator.calculateLiters(roofArea, mm, coeff)
                binding.tvPreviewLiters.visibility = if (mm > 0) View.VISIBLE else View.GONE
                binding.tvPreviewLiters.text = "Estimated: %.1f liters".format(liters)
            }
        })

        binding.btnSaveEntry.setOnClickListener {
            val rainfall = WaterCalculator.parseDouble(binding.etRainfallMm.text.toString())
            if (rainfall == null || rainfall <= 0) {
                binding.etRainfallMm.error = "Enter valid rainfall in mm"
                return@setOnClickListener
            }
            val liters = WaterCalculator.calculateLiters(roofArea, rainfall, coeff)
            viewModel.saveEntry(
                RainfallEntry(
                    rainfallMm = rainfall,
                    roofAreaSqFt = roofArea,
                    runoffCoefficient = coeff,
                    litersCollected = liters,
                    notes = binding.etNotes.text.toString()
                )
            ) {
                Toast.makeText(requireContext(), "Saved! \uD83D\uDCA7 %.1f L collected".format(liters), Toast.LENGTH_LONG).show()
                findNavController().navigateUp()
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
