package com.jalsanchay.tracker.ui.dashboard

import android.content.res.ColorStateList
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.preference.PreferenceManager
import com.jalsanchay.tracker.R
import com.jalsanchay.tracker.databinding.FragmentDashboardBinding
import com.jalsanchay.tracker.utils.WaterCalculator

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val viewModel: DashboardViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val prefs = PreferenceManager.getDefaultSharedPreferences(requireContext())

        if (!prefs.getBoolean("setup_complete", false)) {
            findNavController().navigate(R.id.action_dashboard_to_setup)
            return
        }

        val tankCapacity = prefs.getFloat("tank_capacity", 1000f).toDouble()

        viewModel.todayEntry.observe(viewLifecycleOwner) { entry ->
            binding.tvTodayLiters.text = "%.1f L".format(entry?.litersCollected ?: 0.0)
            binding.tvTodayRainfall.text = "%.1f mm".format(entry?.rainfallMm ?: 0.0)
        }

        viewModel.totalLiters.observe(viewLifecycleOwner) { total ->
            binding.tvTotalLiters.text = "%.0f L".format(total)
            binding.tvHouseholdDays.text = "%.1f household water days".format(WaterCalculator.toHouseholdDays(total))
            binding.tvCo2Saved.text = "%.2f kg CO\u2082 saved".format(WaterCalculator.co2SavedKg(total))
            val pct = WaterCalculator.tankFillPercent(total, tankCapacity)
            binding.progressWaterTank.progress = pct
            binding.tvTankPercent.text = "$pct%"
            val color = when {
                pct >= 75 -> requireContext().getColor(R.color.tank_full)
                pct >= 40 -> requireContext().getColor(R.color.tank_medium)
                else      -> requireContext().getColor(R.color.tank_low)
            }
            binding.progressWaterTank.progressTintList = ColorStateList.valueOf(color)
        }

        viewModel.monthlyLiters.observe(viewLifecycleOwner) { monthly ->
            binding.tvMonthlyLiters.text = "%.0f L this month".format(monthly)
        }

        binding.fabAddEntry.setOnClickListener { findNavController().navigate(R.id.action_dashboard_to_entry) }
        binding.btnViewReport.setOnClickListener { findNavController().navigate(R.id.action_dashboard_to_report) }
        binding.btnViewTips.setOnClickListener { findNavController().navigate(R.id.action_dashboard_to_tips) }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.dashboard_menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_settings) {
            findNavController().navigate(R.id.action_dashboard_to_setup); return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
