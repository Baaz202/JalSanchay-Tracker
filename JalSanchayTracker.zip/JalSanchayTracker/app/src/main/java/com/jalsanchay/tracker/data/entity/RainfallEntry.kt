package com.jalsanchay.tracker.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "rainfall_entries")
data class RainfallEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: Long = System.currentTimeMillis(),
    val rainfallMm: Double,
    val roofAreaSqFt: Double,
    val runoffCoefficient: Double,
    val litersCollected: Double,
    val notes: String = ""
)
