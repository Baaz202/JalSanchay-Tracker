package com.jalsanchay.tracker.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.jalsanchay.tracker.data.entity.RainfallEntry

@Dao
interface RainfallDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: RainfallEntry): Long

    @Delete
    suspend fun delete(entry: RainfallEntry)

    @Query("SELECT * FROM rainfall_entries ORDER BY date DESC")
    fun getAllEntries(): LiveData<List<RainfallEntry>>

    @Query("SELECT * FROM rainfall_entries WHERE date >= :startOfDay AND date <= :endOfDay LIMIT 1")
    fun getTodayEntry(startOfDay: Long, endOfDay: Long): LiveData<RainfallEntry?>

    @Query("SELECT SUM(litersCollected) FROM rainfall_entries")
    fun getTotalLiters(): LiveData<Double?>

    @Query("SELECT SUM(litersCollected) FROM rainfall_entries WHERE date >= :startOfMonth")
    fun getMonthlyLiters(startOfMonth: Long): LiveData<Double?>

    @Query("SELECT * FROM rainfall_entries WHERE date >= :startOfMonth ORDER BY date ASC")
    fun getMonthlyEntries(startOfMonth: Long): LiveData<List<RainfallEntry>>
}
